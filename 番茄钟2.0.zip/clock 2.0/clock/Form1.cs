﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace clock
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private Point mPoint;
        bool TomatoClock = false;

        string color;
        string resttime = "5";
        string worktime = "25";
        string colorz;



        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool MessageBeep(uint uType);      


        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            mPoint = new Point(e.X, e.Y);
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Location = new Point(this.Location.X + e.X - mPoint.X, this.Location.Y + e.Y - mPoint.Y);
            }
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
           if(!TomatoClock)
                label1.Text=DateTime.Now.Hour.ToString()+":"+DateTime.Now.Minute.ToString()+":"+DateTime.Now.Second.ToString();
           label2.Text = DateTime.Now.ToLongDateString().ToString();
        }

        private void label2_MouseDown(object sender, MouseEventArgs e)
        {
            mPoint = new Point(e.X, e.Y);
        }

        private void label2_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Location = new Point(this.Location.X + e.X - mPoint.X, this.Location.Y + e.Y - mPoint.Y);
            }
        }

        private void label1_MouseDown(object sender, MouseEventArgs e)
        {
            mPoint = new Point(e.X, e.Y);
        }

        private void label1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Location = new Point(this.Location.X + e.X - mPoint.X, this.Location.Y + e.Y - mPoint.Y);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TomatoClock = true;
            button2.Visible = true;
            button1.Visible = false;

        }
        int m;
        int s = 0;
        int i = 0;
        int r;
        private void timer2_Tick(object sender, EventArgs e)
        {
            
            if(TomatoClock)
            {
                if (s == 0)
                {
                    m--;
                    s = 60;
                }
                s--;
                label1.Text = m.ToString()+":"+s.ToString();
                if (s <= 0 && m <= 0)
                {
                    i++;
                    MessageBeep(1);
                    MessageBox.Show("时间到了", "番茄钟");
                    if (s <= 0 && m <= 0 && i == 2)
                    {
                        button2.Visible = false;
                        TomatoClock = false;
                    }
                    m = r;
                    //s = 3;
                }
                    
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            TomatoClock = false;
            button2.Visible = false;
            button1.Visible = true;
        }

        private void 设置ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            /*
            label1.Visible = false;
            label2.Visible = false;
            button1.Visible = false;
            button2.Visible = false;
            numericUpDown1.Visible = true;
            numericUpDown2.Visible = true;
            comboBox1.Visible = true;
            button3.Visible = true;
            //button4.Visible = true;
            label3.Visible = true;
            label4.Visible = true;
            label5.Visible = true;
            button4.Visible = true;
             */
            panel1.Visible = false;
            panel2.Visible = true;
            panel1.Location = new Point(500,500);
            panel2.Location = new Point(0, 0);
        }
        string info;
        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedItem = "默认";
            //comboBox2.SelectedItem = "25";
            //comboBox3.SelectedItem = "5";
            comboBox2.SelectedItem = "默认";
            this.ShowInTaskbar = false;
            info = File.ReadAllText(Directory.GetCurrentDirectory() + "/info.pclock");
            int j = 1;
            string d = "";
            string a = "";
            string b = "";
            foreach (char i in info)
            {
                if (i != ' ' && j == 1)
                {
                    d = i.ToString();
                    color += d;

                    if (color == "默认")
                    {
                        this.BackColor = Color.White;
                    }
                    if (color == "蓝色")
                    {
                        this.BackColor = Color.SkyBlue;
                    }
                    if (color == "红色")
                    {
                        this.BackColor = Color.Tomato;
                    }
                    if (color == "绿色")
                    {
                        this.BackColor = Color.LawnGreen;
                    }
                    if (color == "粉色")
                    {
                        this.BackColor = Color.Pink;
                    }

                }
                if (colorz == "默认")
                {
                    label1.ForeColor = Color.Black;
                    label2.ForeColor = Color.Black;
                    label3.ForeColor = Color.Black;
                    label4.ForeColor = Color.Black;
                    label5.ForeColor = Color.Black;
                    label6.ForeColor = Color.Black;
                    button1.ForeColor = Color.Black;
                    button2.ForeColor = Color.Black;
                    button3.ForeColor = Color.Black;
                    button4.ForeColor = Color.Black;

                }
                if (colorz == "蓝色")
                {
                    label1.ForeColor = Color.SkyBlue;
                    label2.ForeColor = Color.SkyBlue;
                    label3.ForeColor = Color.SkyBlue;
                    label4.ForeColor = Color.SkyBlue;
                    label5.ForeColor = Color.SkyBlue;
                    label6.ForeColor = Color.SkyBlue;
                    button1.ForeColor = Color.SkyBlue;
                    button2.ForeColor = Color.SkyBlue;
                    button3.ForeColor = Color.SkyBlue;
                    button4.ForeColor = Color.SkyBlue;

                }
                if (colorz == "红色")
                {
                    label1.ForeColor = Color.Tomato;
                    label2.ForeColor = Color.Tomato;
                    label3.ForeColor = Color.Tomato;
                    label4.ForeColor = Color.Tomato;
                    label5.ForeColor = Color.Tomato;
                    label6.ForeColor = Color.Tomato;
                    button1.ForeColor = Color.Tomato;
                    button2.ForeColor = Color.Tomato;
                    button3.ForeColor = Color.Tomato;
                    button4.ForeColor = Color.Tomato;

                }
                if (colorz == "绿色")
                {
                    label1.ForeColor = Color.LawnGreen;
                    label2.ForeColor = Color.LawnGreen;
                    label3.ForeColor = Color.LawnGreen;
                    label4.ForeColor = Color.LawnGreen;
                    label5.ForeColor = Color.LawnGreen;
                    label6.ForeColor = Color.LawnGreen;
                    button1.ForeColor = Color.LawnGreen;
                    button2.ForeColor = Color.LawnGreen;
                    button3.ForeColor = Color.LawnGreen;
                    button4.ForeColor = Color.LawnGreen;
                }
                if (colorz == "粉色")
                {
                    label1.ForeColor = Color.Pink;
                    label2.ForeColor = Color.Pink;
                    label3.ForeColor = Color.Pink;
                    label4.ForeColor = Color.Pink;
                    label5.ForeColor = Color.Pink;
                    label6.ForeColor = Color.Pink;
                    button1.ForeColor = Color.Pink;
                    button2.ForeColor = Color.Pink;
                    button3.ForeColor = Color.Pink;
                    button4.ForeColor = Color.Pink;
                }
                if (i != ' ' && j == 3)
                {
                    d = i.ToString();
                    a += d; 
                }
                if (i != ' ' && j == 3)
                {
                    d = i.ToString();
                    b += d;
                }
                if (i == ' ')
                    j++;
            }
                r += int.Parse(b);
                m += int.Parse(a);
                this.TopMost = true;
        }
        private void button3_Click(object sender, EventArgs e)
        {

            color = comboBox1.SelectedItem.ToString();
            colorz = comboBox2.SelectedItem.ToString();
            worktime = numericUpDown1.Value.ToString();
            resttime = numericUpDown2.Value.ToString();
            if (color == "默认")
            {
                this.BackColor =Color.White;
                panel1.BackgroundImage = null;
                panel2.BackgroundImage = null;
            }
               if (color == "蓝色")
            {
                this.BackColor = Color.SkyBlue;
                panel1.BackgroundImage = null;
                panel2.BackgroundImage = null;
            }
            if (color == "红色")
            {
                this.BackColor = Color.Tomato;
                panel1.BackgroundImage = null;
                panel2.BackgroundImage = null;
            }
            if (color == "绿色")
            {
                this.BackColor = Color.LawnGreen;
                panel1.BackgroundImage = null;
                panel2.BackgroundImage = null;
            }
            if (color == "粉色")
            {
                this.BackColor = Color.Pink;
                panel1.BackgroundImage = null;
                panel2.BackgroundImage = null;
            }


            if (colorz == "默认")
            {
                label1.ForeColor = Color.Black;
                label2.ForeColor = Color.Black;
                label3.ForeColor = Color.Black;
                label4.ForeColor = Color.Black;
                label5.ForeColor = Color.Black;
                label6.ForeColor = Color.Black;
                button1.ForeColor = Color.Black;
                button2.ForeColor = Color.Black;
                button3.ForeColor = Color.Black;
                button4.ForeColor = Color.Black;
                
            }
            if (colorz == "蓝色")
            {
                label1.ForeColor = Color.SkyBlue;
                label2.ForeColor = Color.SkyBlue;
                label3.ForeColor = Color.SkyBlue;
                label4.ForeColor = Color.SkyBlue;
                label5.ForeColor = Color.SkyBlue;
                label6.ForeColor = Color.SkyBlue;
                button1.ForeColor = Color.SkyBlue;
                button2.ForeColor = Color.SkyBlue;
                button3.ForeColor = Color.SkyBlue;
                button4.ForeColor = Color.SkyBlue;
                
            }
            if (colorz == "红色")
            {
                label1.ForeColor = Color.Tomato;
                label2.ForeColor = Color.Tomato;
                label3.ForeColor = Color.Tomato;
                label4.ForeColor = Color.Tomato;
                label5.ForeColor = Color.Tomato;
                label6.ForeColor = Color.Tomato;
                button1.ForeColor = Color.Tomato;
                button2.ForeColor = Color.Tomato;
                button3.ForeColor = Color.Tomato;
                button4.ForeColor = Color.Tomato;
                
            }
            if (colorz == "绿色")
            {
                label1.ForeColor = Color.LawnGreen;
                label2.ForeColor = Color.LawnGreen;
                label3.ForeColor = Color.LawnGreen;
                label4.ForeColor = Color.LawnGreen;
                label5.ForeColor = Color.LawnGreen;
                label6.ForeColor = Color.LawnGreen;
                button1.ForeColor = Color.LawnGreen;
                button2.ForeColor = Color.LawnGreen;
                button3.ForeColor = Color.LawnGreen;
                button4.ForeColor = Color.LawnGreen;
            }
            if (colorz == "粉色")
            {
                label1.ForeColor = Color.Pink;
                label2.ForeColor = Color.Pink;
                label3.ForeColor = Color.Pink;
                label4.ForeColor = Color.Pink;
                label5.ForeColor = Color.Pink;
                label6.ForeColor = Color.Pink;
                button1.ForeColor = Color.Pink;
                button2.ForeColor = Color.Pink;
                button3.ForeColor = Color.Pink;
                button4.ForeColor = Color.Pink;
            }


            m = int.Parse(numericUpDown1.Value.ToString());
            r = int.Parse(numericUpDown2.Value.ToString());
            File.WriteAllText(Directory.GetCurrentDirectory()+"/info.pclock",color+ " "+colorz +" " + m + " "+  r);
            /*
            label1.Visible = true;
            label2.Visible = true;
            button1.Visible = true;
            button2.Visible = false;
            numericUpDown1.Visible = false;
            numericUpDown2.Visible = false;
            comboBox1.Visible = false;
            button3.Visible = false;
            //button4.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            button4.Visible = false;
             */
            panel1.Visible = true;
            panel2.Visible = false;
            panel1.Location = new Point(0, 0);
            panel2.Location = new Point(500, 500);
            

        }

        private void button4_Click(object sender, EventArgs e)
        {
            
            openFileDialog1.ShowDialog();
            if (openFileDialog1.FileName != "")
            {
                this.panel1.BackgroundImage = Image.FromFile(openFileDialog1.FileName);
                this.panel2.BackgroundImage = Image.FromFile(openFileDialog1.FileName);
                comboBox1.SelectedItem= "图片";
            }
            label1.ForeColor = Color.White;
       
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Location = new Point(this.Location.X + e.X - mPoint.X, this.Location.Y + e.Y - mPoint.Y);
            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            mPoint = new Point(e.X, e.Y);
        }

        private void panel2_MouseDown(object sender, MouseEventArgs e)
        {
            mPoint = new Point(e.X, e.Y);
        }

        private void panel2_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Location = new Point(this.Location.X + e.X - mPoint.X, this.Location.Y + e.Y - mPoint.Y);
            }
        }

        private void 关于ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
        }       
    }
}
